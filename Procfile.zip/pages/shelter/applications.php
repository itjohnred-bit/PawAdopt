<?php
require_once __DIR__ . '/../../includes/functions.php';
requireRole('SHELTER');

$pageTitle = 'Applications';
$user = getCurrentUser();
$db   = Database::getInstance();

$petFilter    = (int)($_GET['pet'] ?? 0);
$statusFilter = trim($_GET['status'] ?? '');
$focusApp     = (int)($_GET['app'] ?? 0);

$where  = ['p.shelter_id = ?'];
$params = [$user['user_id']];

if ($petFilter) {
    $where[]  = 'aa.pet_id = ?';
    $params[] = $petFilter;
}
if ($statusFilter !== '') {
    $where[]  = 'aa.status = ?';
    $params[] = $statusFilter;
}

$apps = $db->fetchAll(
    "SELECT aa.*,
            p.name AS pet_name,
            p.species,
            u.username AS adopter_username,
            u.email AS adopter_email,
            ap.full_name AS adopter_name,
            ap.phone AS adopter_phone,
            ap.city AS adopter_city,
            ap.bio AS adopter_bio,
            (
                SELECT pp.photo_url
                FROM pet_photos pp
                WHERE pp.pet_id = p.pet_id AND pp.is_primary = 1
                LIMIT 1
            ) AS pet_photo
     FROM adoption_applications aa
     JOIN pets p ON aa.pet_id = p.pet_id
     JOIN users u ON aa.adopter_id = u.user_id
     LEFT JOIN adopter_profiles ap ON aa.adopter_id = ap.adopter_id
     WHERE " . implode(' AND ', $where) . "
     ORDER BY aa.submitted_at DESC",
    $params
);

$myPets = $db->fetchAll(
    "SELECT pet_id, name
     FROM pets
     WHERE shelter_id = ? AND status != 'Removed'
     ORDER BY name",
    [$user['user_id']]
);

include __DIR__ . '/../../includes/header.php';

function appStatusBadgeClass(string $status): string {
    return match ($status) {
        'Approved'     => 'bg-success',
        'Rejected'     => 'bg-danger',
        'Under Review' => 'bg-warning text-dark',
        'Cancelled'    => 'bg-secondary',
        default        => 'bg-info text-dark',
    };
}
?>

<div class="page-header">
    <h1 class="page-title"><span class="icon">📋</span> Adoption Applications</h1>
    <span class="text-muted"><?= count($apps) ?> application<?= count($apps) !== 1 ? 's' : '' ?></span>
</div>

<div class="filter-bar">
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
        <select name="pet" class="form-control" onchange="this.form.submit()">
            <option value="">All Pets</option>
            <?php foreach ($myPets as $p): ?>
                <option value="<?= (int)$p['pet_id'] ?>" <?= $petFilter === (int)$p['pet_id'] ? 'selected' : '' ?>>
                    <?= sanitize($p['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <select name="status" class="form-control" onchange="this.form.submit()">
            <option value="">All Statuses</option>
            <?php foreach (['Submitted', 'Under Review', 'Approved', 'Rejected', 'Cancelled'] as $s): ?>
                <option value="<?= $s ?>" <?= $statusFilter === $s ? 'selected' : '' ?>>
                    <?= $s ?>
                </option>
            <?php endforeach; ?>
        </select>

        <?php if ($petFilter || $statusFilter): ?>
            <a href="?" class="btn btn-secondary btn-sm">Clear</a>
        <?php endif; ?>
    </form>
</div>

<?php if (empty($apps)): ?>
    <div class="empty-state">
        <div class="empty-icon">📋</div>
        <h3>No applications found</h3>
        <p>Applications will appear here when adopters apply for your pets.</p>
    </div>
<?php else: ?>
    <div style="display:flex;flex-direction:column;gap:16px">
        <?php foreach ($apps as $app): ?>
            <?php
                $photo = !empty($app['pet_photo'])
                    ? rtrim(APP_URL, '/') . '/' . ltrim($app['pet_photo'], '/')
                    : rtrim(APP_URL, '/') . '/assets/images/pet-placeholder.png';

                $highlighted = ($focusApp === (int)$app['application_id']);
                $status      = (string)($app['status'] ?? 'Submitted');
                $canReview   = !in_array($status, ['Approved', 'Rejected', 'Cancelled'], true);
                $appId       = (int)($app['application_id'] ?? 0);
            ?>
            <div class="card <?= $highlighted ? 'highlight-card' : '' ?>"
                 id="app-<?= $appId ?>"
                 data-application-id="<?= $appId ?>"
                 data-status="<?= sanitize($status) ?>"
                 style="<?= $highlighted ? 'border:2px solid var(--teal)' : '' ?>">

                <div style="display:flex;gap:16px;flex-wrap:wrap">
                    <img src="<?= sanitize($photo) ?>"
                         alt="<?= sanitize($app['pet_name']) ?>"
                         style="width:80px;height:80px;border-radius:12px;object-fit:cover;flex-shrink:0"
                         onerror="this.src='<?= rtrim(APP_URL, '/') ?>/assets/images/pet-placeholder.png'">

                    <div style="flex:1;min-width:220px">
                        <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px">
                            <div>
                                <span class="fw-bold" style="font-size:1.05rem">
                                    <?= sanitize($app['adopter_name'] ?: $app['adopter_username']) ?>
                                </span>
                                <span class="text-muted"> wants to adopt </span>
                                <span class="fw-bold text-teal"><?= sanitize($app['pet_name']) ?></span>
                            </div>

                            <div style="display:flex;align-items:center;gap:8px">
                                <span class="badge js-app-status-badge <?= appStatusBadgeClass($status) ?>">
                                    <?= sanitize($status) ?>
                                </span>
                                <span class="text-muted" style="font-size:.78rem">
                                    <?= !empty($app['submitted_at']) ? date('M j, Y', strtotime($app['submitted_at'])) : '' ?>
                                </span>
                            </div>
                        </div>

                        <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:8px;font-size:.82rem;color:#888">
                            <span><i class="fas fa-envelope"></i> <?= sanitize($app['adopter_email']) ?></span>

                            <?php if (!empty($app['adopter_phone'])): ?>
                                <span><i class="fas fa-phone"></i> <?= sanitize($app['adopter_phone']) ?></span>
                            <?php endif; ?>

                            <?php if (!empty($app['adopter_city'])): ?>
                                <span><i class="fas fa-map-marker-alt"></i> <?= sanitize($app['adopter_city']) ?></span>
                            <?php endif; ?>
                        </div>

                        <?php if (!empty($app['message_to_shelter'])): ?>
                            <div style="margin-top:10px;background:#f8f9fa;border-radius:10px;padding:12px;font-size:.88rem">
                                <strong>Adopter's message:</strong><br>
                                <?= nl2br(sanitize($app['message_to_shelter'])) ?>
                            </div>
                        <?php endif; ?>

                        <div class="js-app-actions" style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
                            <button type="button"
                                    data-action="view"
                                    data-app-id="<?= $appId ?>"
                                    class="btn btn-info btn-sm js-view-btn"
                                    style="background:#0ea5e9;color:#fff;border:none;cursor:pointer;">
                                <i class="fas fa-file-alt"></i> View Application
                            </button>

                            <?php if ($canReview): ?>
                                <?php if ($status === 'Submitted'): ?>
                                    <a href="#"
                                       data-action="under-review"
                                       data-app-id="<?= $appId ?>"
                                       class="js-under-review-link"
                                       style="font-size:.82rem;color:#92400e;text-decoration:underline;align-self:center;cursor:pointer;">
                                        🔍 Mark as Under&nbsp;Review
                                    </a>
                                <?php else: ?>
                                    <span class="js-under-review-label"
                                          style="font-size:.82rem;color:#666;align-self:center;">
                                        🔍 Under Review
                                    </span>
                                <?php endif; ?>

                                <button type="button"
                                        data-action="approve"
                                        data-app-id="<?= $appId ?>"
                                        class="btn btn-success btn-sm js-review-action"
                                        style="cursor:pointer;">
                                    ✅ Approve
                                </button>

                                <button type="button"
                                        data-action="reject"
                                        data-app-id="<?= $appId ?>"
                                        class="btn btn-danger btn-sm js-review-action"
                                        style="cursor:pointer;">
                                    ❌ Reject
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- Review Modal -->
<div class="modal fade" id="reviewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius:16px;overflow:hidden;border:none;box-shadow:0 20px 60px rgba(0,0,0,.2);">
            <div class="modal-header" style="background:#f8fbf9;border-bottom:1px solid #eee;">
                <h5 class="modal-title" id="reviewModalTitle">Review Application</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <p id="reviewModalPrompt" class="mb-3 text-muted">
                    Confirm this review action.
                </p>

                <div class="form-group">
                    <label for="decisionNote" class="form-label">Decision Note (optional)</label>
                    <textarea id="decisionNote"
                              class="form-control"
                              rows="4"
                              placeholder="Add a short explanation for your decision..."></textarea>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="confirmReviewBtn">
                    Confirm
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Application Detail Modal -->
<div class="modal fade" id="appDetailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content" style="border-radius:18px;border:none;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.22);">
            <div class="modal-header" style="background:#f8fbf9;border-bottom:1px solid #eee;padding:20px 24px;">
                <h5 class="modal-title" style="color:#0f766e;font-weight:800;" id="appDetailTitle">
                    <i class="fas fa-file-alt me-2"></i> Application Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body p-4" id="appDetailBody">
                <div style="text-align:center;padding:30px;color:#888;">
                    <i class="fas fa-spinner fa-spin"></i> Loading…
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<style>
.custom-scroll::-webkit-scrollbar { width: 6px; }
.custom-scroll::-webkit-scrollbar-track { background: #f1f1f1; }
.custom-scroll::-webkit-scrollbar-thumb { background: #d1d1d1; border-radius: 10px; }
.custom-scroll::-webkit-scrollbar-thumb:hover { background: #bbb; }
</style>

<script>
(function () {
    'use strict';


    const CURRENT_PATH = window.location.pathname;
    const API_BASE     = CURRENT_PATH.replace(/\/pages\/.*$/, '/api/');

 
    let reviewAppId        = null;
    let reviewStatus       = null;
    let isSubmittingReview = false;


    function escapeHtml(str) {
        if (str === null || str === undefined) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function $(id) {
        return document.getElementById(id);
    }

    function badgeClassForStatus(status) {
        switch (status) {
            case 'Approved':     return 'bg-success';
            case 'Rejected':     return 'bg-danger';
            case 'Under Review': return 'bg-warning text-dark';
            case 'Cancelled':    return 'bg-secondary';
            default:             return 'bg-info text-dark';
        }
    }

    function showToast(message, type) {
        if (typeof window.showToast === 'function') {
            window.showToast(message, type);
            return;
        }
        const existing = document.getElementById('js-toast-fallback');
        if (existing) existing.remove();

        const el = document.createElement('div');
        el.id = 'js-toast-fallback';
        el.textContent = message;
        el.style.cssText =
            'position:fixed;bottom:24px;right:24px;z-index:99999;' +
            'background:' + (type === 'error' ? '#dc2626' : '#0f766e') + ';' +
            'color:#fff;padding:12px 18px;border-radius:10px;font-size:14px;' +
            'box-shadow:0 8px 24px rgba(0,0,0,.18);font-family:inherit;';
        document.body.appendChild(el);
        setTimeout(() => el.remove(), 3500);
    }

    function getModal(id) {
        const el = $(id);
        if (!el) {
            console.error('Modal element not found:', id);
            return null;
        }
        if (typeof bootstrap === 'undefined' || !bootstrap.Modal) {
            console.error('Bootstrap 5 JS is not loaded — falling back to manual show.');
            return {
                show() {
                    el.style.display = 'block';
                    el.classList.add('show');
                    document.body.classList.add('modal-open');
                },
                hide() {
                    el.style.display = 'none';
                    el.classList.remove('show');
                    document.body.classList.remove('modal-open');
                }
            };
        }
        return bootstrap.Modal.getOrCreateInstance(el);
    }

 
    function updateCardStatusUI(appId, status) {
        const card = document.getElementById('app-' + appId);
        if (!card) return;

        card.dataset.status = status;

        const badge = card.querySelector('.js-app-status-badge');
        if (badge) {
            badge.className = 'badge js-app-status-badge ' + badgeClassForStatus(status);
            badge.textContent = status;
        }

        const actions = card.querySelector('.js-app-actions');
        if (!actions) return;

        if (status === 'Under Review') {
            const reviewLink = actions.querySelector('.js-under-review-link');
            if (reviewLink) {
                const span = document.createElement('span');
                span.className = 'js-under-review-label';
                span.style.cssText = 'font-size:.82rem;color:#666;align-self:center;';
                span.textContent = '🔍 Under Review';
                reviewLink.replaceWith(span);
            }
        }

        if (['Approved', 'Rejected', 'Cancelled'].includes(status)) {
            actions.querySelectorAll('.js-review-action, .js-under-review-link, .js-under-review-label')
                .forEach(el => el.remove());
        }
    }

    async function apiRequest(payload) {
        const body = new FormData();
        Object.entries(payload).forEach(([k, v]) => body.append(k, v ?? ''));

        const response = await fetch(API_BASE + 'applications.php', {
            method: 'POST',
            body,
            credentials: 'same-origin'
        });

        let res = null;
        try { res = await response.json(); }
        catch (e) {
            throw new Error('Server returned non-JSON response (HTTP ' + response.status + ').');
        }
        return res;
    }

    async function apiGet(paramsObj) {
        const qs = new URLSearchParams(paramsObj).toString();
        const response = await fetch(API_BASE + 'applications.php?' + qs, {
            credentials: 'same-origin'
        });

        let res = null;
        try { res = await response.json(); }
        catch (e) {
            throw new Error('Server returned non-JSON response (HTTP ' + response.status + ').');
        }
        return res;
    }

 
    function showReviewModal(appId, status) {
        reviewAppId  = Number(appId) || 0;
        reviewStatus = status;

        const modal   = getModal('reviewModal');
        if (!modal) {
            alert('Cannot open review modal — required markup missing.');
            return;
        }
        const title   = $('reviewModalTitle');
        const prompt  = $('reviewModalPrompt');
        const noteEl  = $('decisionNote');
        const confirm = $('confirmReviewBtn');

        if (noteEl) noteEl.value = '';
        if (confirm) confirm.disabled = false;

        if (status === 'Approved') {
            title.textContent = '✅ Approve Application';
            prompt.textContent = 'You are about to approve this adoption application.';
            confirm.textContent = 'Approve Application';
            confirm.classList.remove('btn-primary', 'btn-danger');
            confirm.classList.add('btn-success');
        } else {
            title.textContent = '❌ Reject Application';
            prompt.textContent = 'You are about to reject this adoption application.';
            confirm.textContent = 'Reject Application';
            confirm.classList.remove('btn-primary', 'btn-success');
            confirm.classList.add('btn-danger');
        }

        modal.show();
    }

    async function submitReview() {
        if (!reviewAppId || !reviewStatus || isSubmittingReview) return;

        const note    = (($('decisionNote') || {}).value || '').trim();
        const appId   = reviewAppId;
        const status  = reviewStatus;
        const confirm = $('confirmReviewBtn');

        const originalText = confirm ? confirm.textContent : '';
        isSubmittingReview = true;
        if (confirm) {
            confirm.disabled = true;
            confirm.textContent = 'Processing...';
        }

        try {
            const modal = getModal('reviewModal');
            if (modal) modal.hide();

            const res = await apiRequest({
                action: 'review',
                application_id: appId,
                status: status,
                decision_note: note
            });

            if (res && res.success) {
                updateCardStatusUI(appId, status);
                showToast('Application ' + status + ' ✓', 'success');
                setTimeout(() => window.location.reload(), 600);
                return true;
            }

            showToast((res && res.message) || 'Failed to update application.', 'error');
            return false;
        } catch (e) {
            console.error('submitReview error:', e);
            showToast('Network error: ' + (e.message || e), 'error');
            return false;
        } finally {
            isSubmittingReview = false;
            if (confirm) {
                confirm.disabled = false;
                confirm.textContent = originalText;
            }
        }
    }

    async function markUnderReviewSilently(appId) {
        const card = document.getElementById('app-' + appId);
        if (!card) return false;
        if (card.dataset.status === 'Under Review') return true;

        try {
            const res = await apiRequest({
                action: 'review',
                application_id: appId,
                status: 'Under Review',
                decision_note: ''
            });
            if (res && res.success) {
                updateCardStatusUI(appId, 'Under Review');
                return true;
            }
        } catch (e) {
            console.error('markUnderReviewSilently error:', e);
        }
        return false;
    }

    async function markUnderReviewManually(appId) {
        if (!appId) return;
        const card = document.getElementById('app-' + appId);
        if (card && card.dataset.status === 'Under Review') return;
        try {
            const res = await apiRequest({
                action: 'review',
                application_id: appId,
                status: 'Under Review',
                decision_note: ''
            });
            if (res && res.success) {
                updateCardStatusUI(appId, 'Under Review');
                showToast('Marked as Under Review ✓', 'success');
                setTimeout(() => window.location.reload(), 400);
            } else {
                showToast((res && res.message) || 'Failed.', 'error');
            }
        } catch (e) {
            showToast('Network error: ' + (e.message || e), 'error');
        }
    }

    function renderScreeningSection(screening) {
        const skipKeys = ['action', 'pet_id'];
        const rows = Object.keys(screening || {})
            .filter(key => !skipKeys.includes(key) && screening[key] !== '' && screening[key] != null)
            .map(key => {
                const label = key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
                return ''
                    + '<div style="display:flex;border-bottom:1px dashed #eee;padding:8px 0;gap:12px;">'
                    +   '<div style="flex:0 0 40%;color:#666;font-size:.85rem;font-weight:600;">' + escapeHtml(label) + '</div>'
                    +   '<div style="flex:1;color:#111;font-size:.9rem;word-break:break-word;">' + escapeHtml(String(screening[key])) + '</div>'
                    + '</div>';
            })
            .join('');

        if (rows) {
            return ''
                + '<div style="margin-top:18px;">'
                +   '<h4 style="color:#0f766e;margin:0 0 10px 0;font-size:1rem;">📝 Filled-Up Screening Form</h4>'
                +   '<div class="custom-scroll" style="background:#f8f9fa;border-radius:10px;padding:10px 14px;max-height:340px;overflow-y:auto;">'
                +     rows
                +   '</div>'
                + '</div>';
        }
        return ''
            + '<div style="margin-top:18px;background:#fffbeb;border-left:4px solid #f59e0b;padding:12px;border-radius:8px;color:#92400e;font-size:.85rem;">'
            + '⚠️ No screening form answers recorded for this application.'
            + '</div>';
    }

    function renderStatusBadge(status) {
        return '<span class="badge ' + badgeClassForStatus(status) + '">' + escapeHtml(status || 'Submitted') + '</span>';
    }

    async function viewApplication(appId) {
        console.log('[viewApplication] called with appId =', appId);

        if (!appId) {
            showToast('Invalid application id.', 'error');
            return;
        }

        const modal = getModal('appDetailModal');
        const body  = $('appDetailBody');
        const title = $('appDetailTitle');

        if (!modal || !body || !title) {
            console.error('[viewApplication] missing modal markup', { modal: !!modal, body: !!body, title: !!title });
            showToast('Cannot open details — modal markup missing.', 'error');
            return;
        }

        title.innerHTML = '<i class="fas fa-file-alt me-2"></i> Application Details';
        body.innerHTML =
            '<div style="text-align:center;padding:30px;color:#888;">'
            +   '<i class="fas fa-spinner fa-spin"></i> Loading application #' + escapeHtml(String(appId)) + '…'
            + '</div>';

        modal.show();

        try {
            const res = await apiGet({ action: 'get_detail', id: appId });
            console.log('[viewApplication] api result:', res);

            if (!res || !res.success) {
                body.innerHTML =
                    '<div style="padding:20px;color:#b91c1c;">'
                    +   '<strong>Failed to load application.</strong><br>'
                    +   escapeHtml((res && res.message) || 'Unknown error from server.')
                    + '</div>';
                return;
            }

            const a = res.data || {};

            if (a.status === 'Submitted') {
                const updated = await markUnderReviewSilently(appId);
                if (updated) a.status = 'Under Review';
            }

            let screening = {};
            try {
                screening = a.screening_responses ? JSON.parse(a.screening_responses) : {};
            } catch (e) {
                console.warn('[viewApplication] screening_responses not valid JSON', e);
                screening = {};
            }

            const adopterName   = a.adopter_name || a.adopter_username || 'Adopter';
            const adopterEmail  = a.adopter_email || '';
            const adopterPhone  = a.adopter_phone || '—';
            const adopterCity   = a.adopter_city  || '—';
            const submittedDate = a.submitted_at
                ? new Date(a.submitted_at.replace(' ', 'T')).toLocaleString()
                : '—';

            const adopterBio = a.adopter_bio
                ? '<div style="margin-top:6px;color:#555;font-size:.85rem;font-style:italic;">"'
                    + escapeHtml(a.adopter_bio) + '"</div>'
                : '';

            body.innerHTML = ''
                + '<div style="display:flex;gap:14px;align-items:center;background:#f0fdfa;border-radius:12px;padding:14px;">'
                +   '<div style="width:56px;height:56px;border-radius:50%;background:#0f766e;color:#fff;display:flex;align-items:center;justify-content:center;font-size:1.4rem;font-weight:800;">'
                +     escapeHtml(adopterName.charAt(0).toUpperCase())
                +   '</div>'
                +   '<div style="flex:1;min-width:0">'
                +     '<div style="font-weight:800;font-size:1.05rem;">' + escapeHtml(adopterName) + '</div>'
                +     '<div style="color:#555;font-size:.82rem;"><i class="fas fa-envelope"></i> ' + escapeHtml(adopterEmail) + '</div>'
                +     '<div style="color:#555;font-size:.82rem;"><i class="fas fa-phone"></i> ' + escapeHtml(adopterPhone)
                +       '&nbsp;&nbsp;<i class="fas fa-map-marker-alt"></i> ' + escapeHtml(adopterCity)
                +     '</div>'
                +     adopterBio
                +   '</div>'
                + '</div>'
                + '<div style="margin-top:14px;display:flex;gap:16px;flex-wrap:wrap;font-size:.85rem;color:#444;">'
                +   '<span><strong>Pet:</strong> 🐾 ' + escapeHtml(a.pet_name || '') + '</span>'
                +   '<span><strong>Submitted:</strong> ' + escapeHtml(submittedDate) + '</span>'
                +   '<span><strong>Status:</strong> ' + renderStatusBadge(a.status || 'Submitted') + '</span>'
                + '</div>'
                + (a.message_to_shelter
                    ? '<div style="margin-top:14px;background:#f8f9fa;border-radius:10px;padding:12px;font-size:.88rem;">'
                        + '<strong>💬 Message from Adopter:</strong><br>'
                        + escapeHtml(a.message_to_shelter)
                        + '</div>'
                    : '')
                + renderScreeningSection(screening);
        } catch (e) {
            console.error('[viewApplication] error:', e);
            body.innerHTML =
                '<div style="padding:20px;color:#b91c1c;">'
                +   '<strong>Network error.</strong><br>'
                +   escapeHtml(e.message || String(e))
                + '</div>';
        }
    }


    window.viewApplication          = viewApplication;
    window.showReviewModal          = showReviewModal;
    window.submitReview             = submitReview;
    window.markUnderReviewManually  = markUnderReviewManually;

    document.addEventListener('click', function (event) {
        const target = event.target.closest('[data-action]');
        if (!target) return;

        const action = target.getAttribute('data-action');
        const appId  = parseInt(target.getAttribute('data-app-id'), 10) || 0;

        if (action === 'under-review') {
            event.preventDefault();
            markUnderReviewManually(appId);
            return;
        }
        if (action === 'approve') {
            event.preventDefault();
            showReviewModal(appId, 'Approved');
            return;
        }
        if (action === 'reject') {
            event.preventDefault();
            showReviewModal(appId, 'Rejected');
            return;
        }
        if (action === 'view') {
            event.preventDefault();
            viewApplication(appId);
            return;
        }
    });


    const confirmBtn = $('confirmReviewBtn');
    if (confirmBtn) confirmBtn.addEventListener('click', submitReview);


    const reviewModalEl = $('reviewModal');
    if (reviewModalEl) {
        reviewModalEl.addEventListener('hidden.bs.modal', () => {
            if (!isSubmittingReview) {
                reviewAppId  = null;
                reviewStatus = null;
                const note = $('decisionNote');
                if (note) note.value = '';
            }
        });
    }

    console.log('[applications.php] JS bundle ready, API_BASE =', API_BASE);
})();
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
